# Study Guide: Gaussian Generative Models for Classification

## The Core Idea

A **generative model** flips classification on its head. Instead of directly learning a decision boundary (like logistic regression or SVMs do), we model *how the data is generated* for each class, then use Bayes' rule to classify.

For each class `j`, we assume the data follows a multivariate Gaussian distribution:

```
P_j(x) = N(x | mu_j, Sigma_j)
```

To classify a new point `x`, we pick the class `j` that maximizes:

```
pi_j * P_j(x)
```

where `pi_j` is the prior probability of class `j` (just the fraction of training data with label `j`).

---

## Why Log-Probabilities Matter

In 784 dimensions, the Gaussian pdf gives astronomically small numbers — think `e^(-1000)`. Your computer can't store that; it just rounds to zero. So we work with **log-probabilities** instead:

```
log(pi_j) + log(P_j(x))
```

This is mathematically equivalent (log is monotonic, so the argmax doesn't change) but numerically stable. Python's `scipy.stats.multivariate_normal.logpdf()` handles this for us.

---

## Fitting the Model (Training)

Training a Gaussian generative model is refreshingly simple compared to neural nets:

1. **Class priors** `pi_j`: just count what fraction of training images are digit `j`
2. **Class means** `mu_j`: average all the images with label `j` (these end up looking like blurry versions of each digit)
3. **Class covariances** `Sigma_j`: compute the covariance matrix of all images with label `j`

No gradient descent, no iterations, no hyperparameter tuning (well, almost — see below).

---

## The Regularization Problem

Here's where things get tricky. Each covariance matrix `Sigma_j` is 784×784. For it to be invertible (which the Gaussian pdf requires), we need at least 784 data points per class. We have about 5000-6000 per digit, so that sounds fine — but in practice the matrices end up **nearly singular** because many pixel dimensions are highly correlated.

The fix: **add `c * I` to each covariance matrix**, where `I` is the 784×784 identity matrix and `c` is a positive constant. This bumps up every eigenvalue by `c`, guaranteeing invertibility.

```python
Sigma_j_regularized = Sigma_j + c * np.eye(784)
```

### What does `c` do intuitively?

- **Too small**: the covariance matrices are still nearly singular, computations blow up
- **Too large**: you're drowning out the actual covariance structure with noise; every class looks the same (spherical Gaussian), and the model degenerates into nearest-centroid classification
- **Just right**: you smooth out the numerical issues while preserving the meaningful covariance structure

### How to choose `c`

We use a **validation set**:

1. Hold out 10,000 of the 60,000 training images
2. Fit the model on the remaining 50,000
3. Try a bunch of `c` values: {1, 51, 101, ..., 10001}
4. For each `c`, classify the validation set and record the error rate
5. Pick the `c` with the lowest validation error

In practice, the validation error curve drops steeply at first (as `c` fixes the singularity issues) and then gradually climbs (as `c` starts destroying useful information). The sweet spot is around `c ≈ 2000-2500`, giving a test error around **4.25%**.

---

## Results on MNIST

| Metric | Value |
|--------|-------|
| Best `c` | ~2151 (varies with random split) |
| Validation error | ~4.3% |
| Test error | ~4.25% |

For comparison, 1-nearest-neighbor gets 3.09% on the same data. So the Gaussian model is slightly worse, but it's *much* faster at test time (just compute 10 log-probabilities vs. comparing against 60,000 stored images) and *much* more compact (store 10 means and covariances vs. the entire training set).

### Common misclassifications

The model tends to confuse digits that look visually similar:
- **2 vs 8**: some 2s have loops that look like 8s
- **7 vs 9**: a 7 with a crossbar can look like a 9
- **6 vs 0**: a round 6 can be mistaken for 0

---

## 2D Boundary Shapes

The decision boundary between two Gaussian classes is determined by where:

```
log(pi_0) + log(P_0(x)) = log(pi_1) + log(P_1(x))
```

Expanding the Gaussian log-pdfs, this becomes a **quadratic equation** in `x`. In 2D, the solutions to quadratic equations are **conic sections**: lines, circles, ellipses, parabolas, or hyperbolas.

### Key insight: same covariance → linear boundary

When `Sigma_0 = Sigma_1`, the quadratic terms `x^T Sigma^{-1} x` are identical on both sides and cancel out. What's left is linear in `x`, so the boundary is a straight line (or hyperplane in higher dimensions).

### Different covariances → curved boundaries

When the covariances differ, the quadratic terms don't cancel, and you get curves:

| Sigma_0 | Sigma_1 | Boundary shape | Why |
|---------|---------|---------------|-----|
| `[[1,0],[0,1]]` | `[[1,0],[0,1]]` | Linear (axis-aligned) | Same covariance → quadratic terms cancel |
| `[[2,½],[½,1]]` | `[[2,½],[½,1]]` | Linear (tilted) | Still same covariance, but off-diagonal terms rotate the line |
| `[[16,0],[0,16]]` | `[[1,0],[0,1]]` | Circle | Both isotropic but different scales → symmetric in all directions |
| `[[16,0],[0,2]]` | `[[1,0],[0,1]]` | Ellipse | Anisotropic scaling → stretched circle |
| `[[1,0],[0,4]]` | `[[16,0],[0,1]]` | Hyperbola | Each class is stretched in a *different* direction |

---

## Key Takeaways

1. **Generative models are elegant**: fit simple distributions per class, classify via Bayes' rule. No iterative optimization needed.

2. **Regularization is essential in high dimensions**: without it, the covariance matrices are singular and the model breaks. The regularization constant `c` is chosen by validation.

3. **The boundary shape is determined by the covariance structure**: equal covariances give linear boundaries, different covariances give quadratic curves (circles, ellipses, hyperbolas).

4. **There's a tradeoff between model complexity and robustness**: the Gaussian model is simple and fast but makes strong assumptions. It can't capture the complex, nonlinear structure that methods like neural networks can, but it's a great baseline and gives surprisingly good results (95.75% accuracy on MNIST with zero tuning beyond `c`).

5. **Log-probabilities are your friend**: always work in log-space when dealing with high-dimensional probability distributions to avoid numerical underflow.
